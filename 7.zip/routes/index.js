const express = require('express');
const router = express.Router();
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const isLogin = require('../middleware/isLogin');

// GET /api/projects - fetch projects assigned to logged-in user
router.get('/api/projects', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  try {
    // Get all projects
    const projects = await Project.findAll({ attributes: ['id', 'name', 'description', 'status', 'assigned_users', 'created_at'] });
    // Filter projects where userId is in assigned_users CSV
    const userProjects = projects.filter(p => {
      if (!p.assigned_users) return false;
      return p.assigned_users.split(',').map(id => id.trim()).includes(String(userId));
    });
    res.json(userProjects);
  } catch (err) {
    console.error('API /api/projects error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});

// GET /api/projects/:id - fetch project details
router.get('/api/projects/:id', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  const projectId = req.params.id;
  try {
    const project = await Project.findByPk(projectId);
    if (!project) return res.status(404).json({ message: 'Project not found.' });
    // Check if user is assigned
    if (!project.assigned_users || !project.assigned_users.split(',').map(id => id.trim()).includes(String(userId))) {
      return res.status(403).json({ message: 'Not authorized.' });
    }
    // Get assigned user details
    let assignedUserIds = project.assigned_users.split(',').map(id => id.trim());
    const assignedUsers = await User.findAll({ where: { id: assignedUserIds }, attributes: ['id', 'username', 'role'] });
    // Return project details with assigned users
    res.json({
      id: project.id,
      name: project.name,
      description: project.description,
      status: project.status,
      created_at: project.created_at,
      assigned_users: assignedUsers
    });
  } catch (err) {
    console.error('API /api/projects/:id error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});


const User = sequelize.define('User', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  username: { type: DataTypes.STRING },
  role: { type: DataTypes.STRING },
  email: { type: DataTypes.STRING },
  password: { type: DataTypes.STRING },
  created_at: { type: DataTypes.DATE },
}, { tableName: 'users', timestamps: false });

const Project = sequelize.define('Project', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING },
  assigned_users: { type: DataTypes.STRING }, // CSV of user IDs
  status: { type: DataTypes.STRING }, // Add status field for project stats
}, { tableName: 'projects', timestamps: false });

const Task = sequelize.define('Task', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.TEXT },
  assigned_to: { type: DataTypes.INTEGER, allowNull: false },
  due_date: { type: DataTypes.DATE, allowNull: false },
  status: { 
    type: DataTypes.ENUM('pending', 'in_progress', 'completed'),
    defaultValue: 'pending'
  },
  created_at: { 
    type: DataTypes.DATE,
    defaultValue: Sequelize.NOW
  }
}, { 
  tableName: 'tasks', 
  timestamps: false 
});

// GET /api/home - dashboard data (protected)
router.get('/api/home', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  try {
    // Get user info
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }
    
    // Get projects assigned to user
    const projects = await Project.findAll({
      attributes: ['id', 'name', 'assigned_users', 'status']
    });
    const userProjects = projects.filter(p => 
      p.assigned_users && 
      p.assigned_users.split(',').map(id => id.trim()).includes(String(userId))
    );
    
    // Get tasks assigned to user
    const userTasks = await Task.findAll({
      where: { assigned_to: userId },
      attributes: ['id', 'name', 'due_date', 'status']
    });
    
    // Get next upcoming task (simplified query)
    const nextTask = await Task.findOne({ 
      where: { 
        assigned_to: userId,
        status: ['pending', 'in_progress']
      },
      order: [['due_date', 'ASC']],
      attributes: ['id', 'name', 'due_date']
    });

    res.json({
      username: user.username,
      role: user.role,
      projects: userProjects,
      totalProjects: userProjects.length,
      tasks: userTasks,
      totalTasks: userTasks.length,
      pending: userTasks.filter(t => t.status === 'pending').length,
      completed: userTasks.filter(t => t.status === 'completed').length,
      nextTask: nextTask || null
    });
    
  } catch (err) {
    console.error('API /api/home error:', err);
    res.status(500).json({ message: 'Database error.' });
  }
});

// GET /api/tasks - Fetch all tasks for current user
router.get('/api/tasks', async (req, res) => {
  try {
    const tasks = await Task.findAll({
      where: { assigned_to: req.user.id },
      order: [['due_date', 'ASC']],
      attributes: ['id', 'name', 'description', 'due_date', 'status']
    });
    
    res.json(tasks.map(task => ({
      id: task.id,
      title: task.name,
      description: task.description,
      dueDate: task.due_date,
      status: task.status
    })));
    
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

// PUT /api/tasks/:id/complete - Mark task as complete
router.put('/api/tasks/:id/complete', authMiddleware, async (req, res) => {
  try {
    const task = await Task.findOne({
      where: { 
        id: req.params.id, 
        assigned_to: req.user.id 
      }
    });
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found or not assigned to you' });
    }
    
    await task.update({ 
      status: 'completed',
      // You might want to add a completed_at timestamp
      // completed_at: new Date()
    });
    
    res.json({
      message: 'Task marked as complete',
      task: {
        id: task.id,
        title: task.name,
        status: 'completed'
      }
    });
  } catch (error) {
    console.error('Error completing task:', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
});
  
/* GET home page. */
router.get(['/', '/home'], authMiddleware, isLogin, function(req, res) {
  res.sendFile('home.html', { root: 'views' });
});


// GET /projects route - serve projects.html
router.get('/projects', authMiddleware, isLogin, function(req, res) {
  res.sendFile('projects.html', { root: 'views' });
});

// GET /calendar route - serve calendar.html
router.get('/calendar', authMiddleware, isLogin, function(req, res) {
  res.sendFile('calendar.html', { root: 'views' });
});

// GET /login route - redirect to login.html
router.get('/login', function(req, res) {
  res.sendFile('login.html', { root: 'views' });
});

router.get('/test', function(req, res) {
  res.sendFile('al.html', { root: 'views' });
});

router.get('/tasks', function(req, res) {
  res.sendFile('tasks.html', { root: 'views' });
});

// GET /calendar route - serve calendar.html
router.get('/calendar', authMiddleware, isLogin, function(req, res) {
  res.sendFile('calendar.html', { root: 'views' });
});

router.get('/nologin', function(req, res) {
  res.sendFile('nologin.html', { root: 'views' });
});

module.exports = router;
